const express = require("express");
const serverless = require("serverless-http");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const _ = require("lodash");
const path = require("path");

const app = express();
app.set('view engine', 'ejs');

// Setting the views directory path
app.set('views', path.join(__dirname, "../../views"));

// Setting up static file path correctly
app.use(express.static(path.join(__dirname, "../../public")));

// Ignore requests for favicon.ico
app.get('/favicon.ico', (req, res) => res.status(204).end());

app.get("/", (req, res) => {
  res.render("home");
});

app.get("/:postName", (req, res) => {
  const url = _.lowerCase(req.params.postName);
  res.render(url);
});

module.exports.handler = serverless(app);
